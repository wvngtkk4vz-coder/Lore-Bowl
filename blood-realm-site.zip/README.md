# Blood Realm: Fighting Universe

Open `index.html` in any browser. Multiplayer is peer-to-peer (PeerJS).
